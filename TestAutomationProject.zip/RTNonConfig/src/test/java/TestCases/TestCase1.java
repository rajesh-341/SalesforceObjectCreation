package TestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.*;
import DriverActions.*;
import PageObjects.AgencyTilePO;
import PageObjects.CSPagePO;
import PageObjects.InsuredTilePO;
import PageObjects.LocationTilePO;
import PageObjects.LoginPageHomePagePO;

public class TestCase1{
	
	WebDriver driver;
	BrowserActions browserExecution;
	private static final Logger log = LoggerFactory.getLogger(LocationTile.class);
	
	
	Map<String, Object> params = new HashMap<>();
	
	@DataProvider(name = "LocationTileTestData")
    public Object[][] createData() throws IOException 
	{
       String excelFilePath = "D:\\\\ExcelFiles\\\\ReadExcelSelenium01.xlsx";
       return readData(excelFilePath);
    }
	
	public Map<String, String> createParams(String RiskAddress,String OccType,String ConsType,String YearBuilt) 
	{
        Map<String, String> params = new HashMap<>();
        params.put("RiskAddress", RiskAddress);
        params.put("OccType", OccType);
        params.put("ConsType", ConsType);
        params.put("YearBuilt", YearBuilt);
        return params;
    }
	
	
	@BeforeMethod
	public void browserExecution() throws IOException
	{
		browserExecution = new BrowserActions();
		driver = browserExecution.LaunchBrowser();
	}
	
	
	@Test
	public void implementTestCase1() throws IOException, NullPointerException, InterruptedException
	{
	
		LoginPageHomePagePO login1 = new LoginPageHomePagePO(driver);	
		LoginHomePage Home = new LoginHomePage(driver);
		
		AgencyTilePO AgencyPO = new AgencyTilePO(driver);
		AgencyTile Agency = new AgencyTile(driver);
		
		InsuredTilePO InsPO = new InsuredTilePO(driver);
		InsuredTile InsTile = new InsuredTile(driver);
		
		LocationTilePO LocPO = new LocationTilePO(driver);
		LocationTile LocTil = new LocationTile(driver);
		
		CSPagePO CSPO = new CSPagePO(driver);
		CSPage CsPage = new CSPage(driver);
		
		String FilePath = "C:\\Users\\rajesh_b\\eclipse-workspace\\RTNonConfig\\RTNonConfig\\src\\test\\resources\\TestDataFiles\\TestData.xlsx" ;
		
		FileInputStream file = new FileInputStream(FilePath);
		
		XSSFWorkbook book2 = new XSSFWorkbook(file);
		
		XSSFSheet sheet2 = book2.getSheetAt(2);
				
		int rowCount = sheet2.getLastRowNum();
		
	    Object[][] data = new Object[rowCount][1];
		
		Home.loginPage(login1);
		Home.HomePage(login1);
		Agency.AgentAgencyInput(AgencyPO);
		System.out.println("Agency Page Executed");
		InsTile.InsuredTileAction(InsPO, 3);
		LocTil.LocationTileAction(LocPO);
		CsPage.CSPageFunctions(CSPO);
	}
	
	 public void tearDown() throws InterruptedException 
	 {
		 driver.quit();
	 }	 
}