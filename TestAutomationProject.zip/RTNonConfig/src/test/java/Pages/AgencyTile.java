package Pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import PageObjects.AgencyTilePO;

public class AgencyTile{

	WebDriver driver; 
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
	
	public AgencyTile(WebDriver driver) 
	 {
	        this.driver = driver;
	 }
	
	public void AgentAgencyInput(AgencyTilePO AgentAgency)
	{
    			
    	WebElement AgencyInputElement = wait.until(ExpectedConditions.elementToBeClickable(AgentAgency.AgencyAgentField));
    	AgencyInputElement.sendKeys("Jodi Strohm");    	
    	WebElement AgencySuggestion = wait.until(ExpectedConditions.elementToBeClickable(AgentAgency.AgencySuggestion));
    	AgencySuggestion.click();
    	
//    	WebElement AgentInputElement = wait.until(ExpectedConditions.elementToBeClickable(AgentAgency.AgentInput));
//    	AgentInputElement.sendKeys("Jodi");   
//    	WebElement AgentSuggestion = wait.until(ExpectedConditions.elementToBeClickable(AgentAgency.AgentSuggestion));
//    	AgentSuggestion.click();    	
    	
    	WebElement AgencySaveElement = wait.until(ExpectedConditions.elementToBeClickable(AgentAgency.AgencyAgentSave));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AgencySaveElement);
    	AgencySaveElement.click();
	}
	
}
