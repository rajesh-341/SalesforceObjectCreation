package Pages;

import java.io.FileInputStream;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import PageObjects.*;

public class LoginHomePage{

	String filepath = "C:\\Users\\rajesh_b\\eclipse-workspace\\RTNonConfig\\RTNonConfig\\src\\test\\resources\\ConfigFiles\\Inputs.properties";
	WebDriver driver; 
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));

	
	 public LoginHomePage(WebDriver driver) 
	 {
	        this.driver = driver;
	 }
	
	
	public void loginPage(LoginPageHomePagePO login) throws IOException {
		
		FileInputStream file = new FileInputStream(filepath);
		Properties properties = new Properties();
		properties.load(file);
        
    	WebElement Username = wait.until(ExpectedConditions.visibilityOf(login.Username));
    	Username.sendKeys(properties.getProperty("username"));
    	
    	WebElement Password = wait.until(ExpectedConditions.visibilityOf(login.Password));
    	Password.sendKeys(properties.getProperty("password"));
    	
    	WebElement Login = wait.until(ExpectedConditions.visibilityOf(login.LoginButton));
    	Login.click();
		
	}
	
	public void HomePage(LoginPageHomePagePO login)throws IOException
	{
	
		FileInputStream file = new FileInputStream(filepath);
		Properties properties = new Properties();
		properties.load(file);
		
	        switch (properties.getProperty("HomePageAction")) {
	            case "QuoteNow":
	            	
	            	wait.until(ExpectedConditions.visibilityOf(login.QuoteNow));
	            	login.QuoteNow.click();
	                break;
	                
	            case "FindBySub":
	            	wait.until(ExpectedConditions.visibilityOf(login.FindBySubmission));
	            	login.FindBySubmission.click();
	                break;
	                
	            case "FindByQuote":
	            	wait.until(ExpectedConditions.visibilityOf(login.FindByQuote));
	            	login.FindByQuote.click();
	                break;
	                
	            case "FindByPolicy":
	            	wait.until(ExpectedConditions.visibilityOf(login.FindByPolicy));
	            	login.FindByPolicy.click();
	                break;
	                
	            default:
	                throw new IllegalArgumentException("Invalid locator type: ");
	        }
		
	}
}
