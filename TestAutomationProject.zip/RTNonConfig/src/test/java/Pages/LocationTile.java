package Pages;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import PageObjects.LocationTilePO;

public class LocationTile {

	WebDriver driver;
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));

    private static final Logger log = LoggerFactory.getLogger(LocationTile.class);

	
	public LocationTile(WebDriver driver) 
	 {
	        this.driver = driver;
	 }
	
	public void LocationTileAction(LocationTilePO LocPO) throws InterruptedException
	{
		
		WebElement RiskAddressField = wait.until(ExpectedConditions.elementToBeClickable(LocPO.RiskAddress));
		RiskAddressField.sendKeys("450 TEMPLE ST SATELLITE BEACH FL 32937-3257 USA");
		
		WebElement RAddressSuggesstion = wait.until(ExpectedConditions.elementToBeClickable(LocPO.RiskAddressSuggestion));
		RAddressSuggesstion.click();
		
		WebElement DragDown = wait.until(ExpectedConditions.visibilityOf(LocPO.State));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", DragDown);
    	
    	WebElement OccupancyTypeDropdown = wait.until(ExpectedConditions.elementToBeClickable(LocPO.OccupancyType));
    	OccupancyTypeDropdown.click();
    	
    	WebElement OccupancyTypeSuggestion = wait.until(ExpectedConditions.elementToBeClickable(LocPO.OccupancyTypeSuggestion));
    	OccupancyTypeSuggestion.click();
    	
    	
    	if (LocPO.ConstructionType == null) 
    	{
    	    System.out.println("driver is null, cannot find element");
    	}
    	else
    	{
    		System.out.println("driver is not null, cannot find element");
		}
    	Thread.sleep(3000);
    	// wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("custom-loader-container")));
    	WebElement ConsTypeDropdown = wait.until(ExpectedConditions.elementToBeClickable(LocPO.ConstructionType));
    	ConsTypeDropdown.click();
    	
    	
    	WebElement ConsTypeSuggestion = wait.until(ExpectedConditions.elementToBeClickable(LocPO.ConstructionTypeSuggestion));
    	ConsTypeSuggestion.click();
    	
    	WebElement YearBuilt = wait.until(ExpectedConditions.elementToBeClickable(LocPO.Yearbuilt));
    	LocPO.Yearbuilt.sendKeys("2002");
    	
    	WebElement Save = wait.until(ExpectedConditions.elementToBeClickable(LocPO.LocTileSaveButton));
    	Save.click();   	
    	
    	int attempts = 0;
        boolean submissionVisible = false;
        int maxRetries = 5;
        
        while (attempts < maxRetries && !submissionVisible) 
        {
            try 
            {
                // Wait for the Next button to be clickable
                WebElement Next = new WebDriverWait(driver, Duration.ofSeconds(10))
                        .until(ExpectedConditions.elementToBeClickable(LocPO.LocTileNextButton));

                // Focus on the Next button
                ((JavascriptExecutor) driver).executeScript("arguments[0].focus();", Next);

                // Click the Next button
                Next.click();

                // Check if the Submission Summary is visible
                submissionVisible = new WebDriverWait(driver, Duration.ofSeconds(10))
                        .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Submission Summary']"))) != null;

                if (!submissionVisible) 
                {
                    System.out.println("Submission Summary not yet visible, retrying...");
                }

            } catch (Exception e) 
            {
                System.out.println("Attempt " + (attempts + 1) + " failed: " + e.getMessage());
            }

            attempts++;
            
        }
//    	
//    	
//    	
//    	WebElement Next = wait.until(ExpectedConditions.elementToBeClickable(LocPO.LocTileNextButton));
//    	((JavascriptExecutor) driver).executeScript("arguments[0].focus();", Next);
//    	Next.click();
	}
}
