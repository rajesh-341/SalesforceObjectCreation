package Pages;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObjects.InsuredTilePO;

public class InsuredTile {	
	
    private static final Logger log = LogManager.getLogger(InsuredTile.class);
	WebDriver driver;
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));

	
	public InsuredTile(WebDriver driver) 
	 {
	        this.driver = driver;
	 }
	
	public void InsuredTileAction(InsuredTilePO InsPO, int retriesLeft)
	{
		
		WebElement NonConfigMarket = wait.until(ExpectedConditions.elementToBeClickable(InsPO.NonConfigButton));
		NonConfigMarket.click();
			
		WebElement LastName = wait.until(ExpectedConditions.elementToBeClickable(InsPO.LastNameField));
		LastName.sendKeys("LastName");    
    	
    	WebElement FirstName = wait.until(ExpectedConditions.elementToBeClickable(InsPO.FirstNameField));
    	FirstName.sendKeys("FirstName");
    	
    	WebElement DOB = wait.until(ExpectedConditions.elementToBeClickable(InsPO.DOBField));
    	DOB.sendKeys("10/18/1990");    
    	
    	if (InsPO.DOBField == null) 
    	{
    	    System.out.println("driver is null, cannot find element");
    	}
    	else
    	{
    		System.out.println("driver is not null, cannot find element");
		}
    	
    	WebElement PhoneNumber = wait.until(ExpectedConditions.elementToBeClickable(InsPO.PhoneNumberField));
    	PhoneNumber.sendKeys("8458454514");
    	
    	WebElement EmailAddress = wait.until(ExpectedConditions.elementToBeClickable(InsPO.EmailAddressField));
    	EmailAddress.sendKeys("test@email.com");
		
    	WebElement MailingAddress = wait.until(ExpectedConditions.elementToBeClickable(InsPO.MailingAddressField));
    	MailingAddress.sendKeys("2555 TAMIAMI TRL NAPLES FL 34103-4493 USA");
    	
    	WebElement MailAddressSuggestion = wait.until(ExpectedConditions.elementToBeClickable(InsPO.MailAddressSuggestion));
    	MailAddressSuggestion.click();
    	
//       	int attempts = 0;
//        boolean submissionVisible = false;
//        int maxRetries = 5;
//        
//        while (attempts < maxRetries && !submissionVisible) 
//        {
//            try 
//            {
//                // Wait for the Next button to be clickable
//                WebElement InsNextButton = new WebDriverWait(driver, Duration.ofSeconds(10))
//                        .until(ExpectedConditions.elementToBeClickable(InsPO.InsuredNextButton));
//
//                // Focus on the Next button
//                ((JavascriptExecutor) driver).executeScript("arguments[0].focus();", InsNextButton);
//
//                // Click the Next button
//                InsNextButton.click();
//
//                // Check if the Submission Summary is visible
//                submissionVisible = new WebDriverWait(driver, Duration.ofSeconds(10))
//                        .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Submission Summary']"))) != null;
//
//                if (!submissionVisible) 
//                {
//                    System.out.println("Submission Summary not yet visible, retrying...");
//                }
//
//            } catch (Exception e) 
//            {
//                System.out.println("Attempt " + (attempts + 1) + " failed: " + e.getMessage());
//            }
//
//            attempts++;
//            
//        }
    	
        
        WebElement visiblity = InsPO.LocTileRef;
    	
    	boolean isVisible = false;

        while (!isVisible) 
        {
            try 
            {
            	WebElement InsNextButton	= wait.until(ExpectedConditions.elementToBeClickable(InsPO.InsuredNextButton));
            	((JavascriptExecutor) driver).executeScript("arguments[0].focus();", InsNextButton);
            	InsNextButton.click();
                isVisible = wait.until(ExpectedConditions.visibilityOf(visiblity)).isDisplayed();
                if (isVisible) 
                {
                    System.out.println("Visibility element is now visible. Exiting loop.");
                    break;
                }
            } 
            catch (ElementClickInterceptedException e) 
            {
                System.out.println("Element click intercepted, retrying...");
            
            } catch (NullPointerException ne) 
            {
                System.out.println("Visibility element is not found. Continuing to retry...");
            }
        } 
	}
	
	
}