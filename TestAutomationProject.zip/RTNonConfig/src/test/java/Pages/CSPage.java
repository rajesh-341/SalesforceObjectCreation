package Pages;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import PageObjects.CSPagePO;

public class CSPage {

	
	WebDriver driver;
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));

    private static final Logger log = LoggerFactory.getLogger(LocationTile.class);

	
	public CSPage(WebDriver driver) 
	 {
	        this.driver = driver;
	 }
		
	public void CSPageFunctions(CSPagePO CSPO) throws InterruptedException, IOException
	{
		
		WebElement selectLob = wait.until(ExpectedConditions.elementToBeClickable(CSPO.SelectLOB));
		selectLob.sendKeys("Dwelling Tenant Occupied");
			
		WebElement logSuggestion = wait.until(ExpectedConditions.elementToBeClickable(CSPO.LOBSuggestion));
    	Thread.sleep(3000);
		logSuggestion.click();
    
		WebElement CarrierName = wait.until(ExpectedConditions.elementToBeClickable(CSPO.CarrierNameField));
		CarrierName.sendKeys("Evanston");
			
		WebElement CarrierNameSuggestion = wait.until(ExpectedConditions.elementToBeClickable(CSPO.CarrierSuggestion));
		CarrierNameSuggestion.click(); 		
        
        
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
        WebElement CSButton = wait.until(ExpectedConditions.elementToBeClickable(CSPO.SelectCarrierButton));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", CSButton);
    	// wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("custom-loader-container")));

//    	if (CSButton.isDisplayed() && CSButton.isEnabled()) 
//    	{
//    		CSButton.click();
//    	} 
//    	else 
//    	{
//    	    System.out.println("Element is not visible.");
//    	}
    	
    	WebElement visiblity = CSPO.Admitted;
    	
    	boolean isVisible = false;

        while (!isVisible) 
        {
            try 
            {
                CSButton.click();
                isVisible = wait.until(ExpectedConditions.visibilityOf(visiblity)).isDisplayed();
                if (isVisible) 
                {
                    System.out.println("Visibility element is now visible. Exiting loop.");
                    break;
                }
            } 
            catch (ElementClickInterceptedException e) 
            {
                System.out.println("Element click intercepted, retrying...");
            
            } catch (NoSuchElementException ne) 
            {
                System.out.println("Visibility element is not found. Continuing to retry...");
            }
        }
        
        WebElement AdjustCoverage = CSPO.AdjustCovBtn;
        wait.until(ExpectedConditions.visibilityOf(visiblity));
        AdjustCoverage.click();        
        
        WebElement CoverageA = CSPO.CovA;
        ((JavascriptExecutor) driver).executeScript("arguments[0].focus();", CoverageA);
        wait.until(ExpectedConditions.visibilityOf(CoverageA));
        CoverageA.sendKeys("10000");
        
        WebElement save = CSPO.CSSaveBtn;
        ((JavascriptExecutor) driver).executeScript("arguments[0].focus();", save);
        wait.until(ExpectedConditions.elementToBeClickable(save));
        save.click(); 
        
        WebElement CreateQuote = CSPO.CreateQuoteButton;
        //((JavascriptExecutor) driver).executeScript("arguments[0].focus();", save);
        wait.until(ExpectedConditions.elementToBeClickable(CreateQuote));
        CreateQuote.click();            
        
        WebElement QuoteNumber = CSPO.QuoteNumberField;
        WebElement SubmissionNumber = CSPO.SubmissionNumberField;
        wait.until(ExpectedConditions.visibilityOf(SubmissionNumber));
        String QNo =  QuoteNumber.getText();       
        String SNo =  SubmissionNumber.getText(); 
        System.out.println("Quote Number = " + QNo + "Submisssion Number = " + SNo);
        
        String NotepadFilePath = "C:\\Users\\rajesh_b\\eclipse-workspace\\RTNonConfig\\RTNonConfig\\src\\test\\resources\\ConfigFiles\\QuoteNumber.txt";
        
        FileWriter notepad = new FileWriter(NotepadFilePath);
        
        notepad.write("Quote Number = " + QNo + " Submission Number = " + SNo);
        
        notepad.close();
        
	}
	
}