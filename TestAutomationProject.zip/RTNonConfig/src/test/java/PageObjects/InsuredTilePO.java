package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InsuredTilePO {

	WebDriver driver;
	
	
	public InsuredTilePO(WebDriver driver) 
	{
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	
	@FindBy(xpath = "((//form)[2]//div[@class='MuiGrid-root MuiGrid-item MuiGrid-grid-xs-6 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 MuiGrid-grid-lg-4'])[2]//span[@class='MuiIconButton-label']")
	public WebElement NonConfigButton;
	
	@FindBy(xpath = "//*[@placeholder='Last Name *']")
    public WebElement LastNameField;

    @FindBy(xpath = "//*[@placeholder='First Name *']")
    public WebElement FirstNameField;

    @FindBy(id = "Dob")
    public WebElement DOBField;	
    
    @FindBy(xpath = "//*[@name='PhoneNumber']")
    public WebElement PhoneNumberField;
    
    @FindBy(xpath = "//*[@name='EmailAddress']")
    public WebElement EmailAddressField;
    
    @FindBy(xpath = "//*[@placeholder='Enter Insured Mailing Address *']")
    public WebElement MailingAddressField;
    
    @FindBy(xpath = "(//div[@class='pac-item'])[1]")
    public WebElement MailAddressSuggestion;
    
    @FindBy(xpath = "//button[@name='nextButton']")
    public WebElement InsuredNextButton;
    
    @FindBy(xpath = "//*[text()='Location Information']")
    public WebElement LocTileRef;
    
}
