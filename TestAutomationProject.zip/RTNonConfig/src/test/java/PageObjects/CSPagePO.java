package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CSPagePO {

WebDriver driver;
	
	
	public CSPagePO(WebDriver driver) 
	{
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	
	@FindBy(id = "LOB")
	public WebElement SelectLOB;
	
	@FindBy(xpath = "//li[@value='Dwelling Tenant Occupied']")
    public WebElement LOBSuggestion;

    @FindBy(id = "CarrierName")
    public WebElement CarrierNameField;

    @FindBy(xpath = "//*[text()='Evanston Insurance Company']")
    public WebElement CarrierSuggestion;
    
    @FindBy(name = "SelectNonConfiguredMarkets")
    public WebElement SelectCarrierButton;
    	
    @FindBy(xpath = "//*[text()='Non Admitted']")
    public WebElement Admitted;
    
    @FindBy(xpath = "//*[text()='Add Coverages']")
    public WebElement AdjustCovBtn;
    
    @FindBy(xpath = "(//input[@inputmode='numeric'])[1]")
    public WebElement CovA;
    
    @FindBy(xpath = "//button[@name='Save']")
    public WebElement CSSaveBtn;
    
    @FindBy(xpath = "//button[@name='nextButton']")
    public WebElement CreateQuoteButton;
    
    @FindBy(xpath = "(//div[@style='align-self: flex-end;'])[7]//p")
    public WebElement QuoteNumberField;
    
    @FindBy(xpath = "(//div[@class='MuiGrid-root OutputLinkText_class  MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-6 MuiGrid-grid-lg-6'])[2]//p")
    public WebElement SubmissionNumberField;
}
