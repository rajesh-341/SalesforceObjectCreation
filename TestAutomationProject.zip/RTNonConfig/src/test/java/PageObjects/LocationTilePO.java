package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LocationTilePO 
{

	WebDriver driver;
	
	
	public LocationTilePO(WebDriver driver) 
	{
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	
	@FindBy(xpath = "//*[@placeholder='Enter Location Address *']")
	public WebElement RiskAddress;
	
	@FindBy(xpath = "(//div[@class='pac-item'])[1]")
	public WebElement RiskAddressSuggestion;
	
	@FindBy(xpath = "//*[text()='Owner - Primary Residence']")
    public WebElement OccupancyType;
	
	@FindBy(id = "ConstructionType")
    public WebElement ConstructionType;
	
	@FindBy(xpath = "//*[@data-value='Steel']")
    public WebElement ConstructionTypeSuggestion;
	
	@FindBy(xpath = "//*[@name='StateRegionCode']")
    public WebElement State;
	
	@FindBy(xpath = "//*[@data-value='Owner Secondary Residence']")
    public WebElement OccupancyTypeSuggestion;
	
	@FindBy(xpath = "//*[@name='DateBuilt']")
    public WebElement Yearbuilt;
	
	@FindBy(xpath = "//*[@name='SaveBuilding']")
    public WebElement LocTileSaveButton;
	
	@FindBy(xpath = "(//button[@type='submit'])[2]")
    public WebElement LocTileNextButton;
}