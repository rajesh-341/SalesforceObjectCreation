package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import DriverActions.BrowserActions;

public class AgencyTilePO
{

	WebDriver driver;
	
	
	public AgencyTilePO(WebDriver driver) 
	{
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	
	// Locate the AgencyInput field
	@FindBy(id = "AgencyAgentLookUpValue")
    public WebElement AgencyAgentField;

	
	@FindBy(id = "AgencyAgentLookUpValue-option-0")
    public WebElement AgencySuggestion;
	
    // Locate the AgentInput field
    @FindBy(id = "AgentName")
    public WebElement AgentInput;

    @FindBy(id = "AgentName-option-0")
    public WebElement AgentSuggestion;
    
    
    // Agency/ Agent save button
    @FindBy(xpath = "//button[@type='submit']")
    public WebElement AgencyAgentSave;
    
    
   
}
