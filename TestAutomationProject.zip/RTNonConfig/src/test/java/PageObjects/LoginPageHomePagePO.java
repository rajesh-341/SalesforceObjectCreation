package PageObjects;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPageHomePagePO{
	WebDriver driver;
	
	
	public LoginPageHomePagePO(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	@FindBy(id = "email")
    public WebElement Username;

    // Locate the password field
    @FindBy(id = "password")
    public WebElement Password;

    // Locate the login button
    @FindBy(xpath = "//*[@type='submit']")
    public WebElement LoginButton;   
    
 // QuoteNow button
    @FindBy(xpath = "//button[@name='Homeowners']")
    public WebElement QuoteNow;
     
 // Find By Submission button
    @FindBy(xpath = "(//button[@name='Search'])[1]")
    public WebElement FindBySubmission;
    
    
 // Find By Quote button
    @FindBy(xpath = "(//button[@name='Search'])[2]")
    public WebElement FindByQuote;
	
 // Find By Policy button
    @FindBy(xpath = "(//button[@name='Search'])[3]")
    public WebElement FindByPolicy;
}
